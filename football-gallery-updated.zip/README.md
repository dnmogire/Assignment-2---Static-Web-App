# Football Players Gallery

A static web application created for CSC 340 assignment.

## Project Description

This is a simple football players gallery website that showcases information about various football players. Users can browse players, search for specific ones, view detailed information, and submit new players through a form.

## Features

- **Home Page**: Displays 5 football players with their basic information
- **Search Functionality**: Real-time search to filter players by name, position, nationality, or club
- **Details Page**: Detailed profile of a featured player with statistics
- **About Page**: Information about the project and technologies used
- **Add Player Form**: Form to submit new player information

## Pages

1. `index.html` - Main gallery page with player cards and search
2. `details.html` - Detailed information about a specific player
3. `about.html` - Project information and description
4. `form.html` - Form to add new players

## Technologies Used

- HTML5
- CSS3
- JavaScript
- GitHub Pages

## How to Use

1. Navigate to the home page to see all players
2. Use the search bar to filter players
3. Click on "Details" to see more information about a featured player
4. Visit "About" to learn more about the project
5. Use the form to add new players (data is not persisted)

## Installation

Simply open `index.html` in a web browser, or visit the live GitHub Pages link.

## Author

CSC 340 Student

## License

Educational project for CSC 340
